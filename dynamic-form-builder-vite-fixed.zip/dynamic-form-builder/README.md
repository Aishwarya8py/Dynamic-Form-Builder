# Dynamic Form Builder

A React + TypeScript + Vite app to create, preview, and manage dynamic forms with validation and derived fields. Data is stored in `localStorage`.

## 👟 Quickstart
```bash
npm install
npm run dev
# open the URL shown (usually http://localhost:5173)
```

## 🏗 Build
```bash
npm run build
npm run preview
```

## 📦 Project Structure
```
dynamic-form-builder/
├─ src/
│  ├─ components/           # UI components split from the original single-file app
│  ├─ types/                # TypeScript types
│  ├─ utils/                # validation + derived value helpers
│  ├─ styles.css            # CSS extracted from the original app
│  ├─ App.tsx               # Root app
│  └─ main.tsx              # Vite entry
├─ index.html               # App shell
├─ tsconfig.json            # Includes @/* path alias
├─ vite.config.ts           # Vite + alias (and base for GH Pages)
├─ package.json
└─ .github/workflows/deploy.yml  # GitHub Pages deploy workflow
```

## 🚀 Deploy to GitHub Pages (CI)
1. Create a GitHub repo and push this folder.
2. In your repo settings → **Pages**, set **Source** to "GitHub Actions".
3. Ensure your repository name is used as `VITE_BASE` in the workflow (already set).
4. On push to `main`, the Action will build and publish to Pages automatically.

Alternatively, deploy manually:
```bash
npm run build
# serve the dist/ folder with any static host (Netlify, Vercel, Nginx, S3, etc.)
```

## ▲ Deploy to Vercel
- Import the GitHub repo in Vercel.
- Framework preset: **Vite**.
- Build command: `npm run build`
- Output dir: `dist`
- No extra config needed.

## 🔧 Notes
- Path alias `@/*` works both in Vite and TS. If your editor shows red squiggles, restart the TS server in VS Code.
- All forms are persisted under key `formBuilderForms`.
